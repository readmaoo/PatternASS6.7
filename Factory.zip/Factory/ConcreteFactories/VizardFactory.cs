using Godot;
public static class VizardFactory
{
    public static void CreateVizard(Node levelScene)
    {
        var vizardScene = GD.Load<PackedScene>("res://vizard.tscn");
        var node = vizardScene.Instantiate<Unit>();
        node.Init(100, 100);
        node.Position = new Vector2(30, 541);
        levelScene.AddChild(node);
    }

}