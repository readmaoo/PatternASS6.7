using Godot;

public partial class Unit : CharacterBody2D
{
    public int MaxHp { get; private set; }
    public int Hp    { get; private set; }
    public int Damage { get; private set; }
    private bool _inited;
    public Unit Init(int maxHp, int damage)
    {
        if (_inited) return this; 
        MaxHp = maxHp;
        Hp    = maxHp;
        Damage = damage;
        _inited = true;
        return this; 
    }
}