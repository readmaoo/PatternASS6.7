using Godot;

public static class KnightFactory
{
    public static void CreateKnight(Node levelScene)
    {
        var knightScene = GD.Load<PackedScene>("res://knight.tscn");
        var node = knightScene.Instantiate<Unit>();
        node.Init(200, 50);
        node.Position = new Vector2(30,523);
        
        levelScene.AddChild(node);
    }

    
}