using Godot;
public class ArcherFactory
{
    public static void CreateArcher(Node levelScene)
    {
        var archerScene = GD.Load<PackedScene>("res://archer.tscn");
        var node = archerScene.Instantiate<Unit>();
        node.Init(150, 75);
        node.Position = new Vector2(25, 541);
        levelScene.AddChild(node);
    }

}