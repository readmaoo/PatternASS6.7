using Godot;

public partial class HealthLabel : Label
{
    [Export] public NodePath UnitPath;
    private Unit _unit;

    public override void _Ready()
    {
        _unit = GetNode<Unit>(UnitPath);
        _unit.HealthChanged += OnHpChanged;
        _unit.Died += () => Text = "Dead";
        Text = $"{_unit.Hp}/{_unit.MaxHp}";
    }
    private void OnHpChanged(int hp, int maxHp) => Text = $"{hp}/{maxHp}";
}